namespace TP2.Models
{
    public class Country
    {
        public string CountryName { get; set; } = "";
        public string CountryCode { get; set; } = "";
    }
}