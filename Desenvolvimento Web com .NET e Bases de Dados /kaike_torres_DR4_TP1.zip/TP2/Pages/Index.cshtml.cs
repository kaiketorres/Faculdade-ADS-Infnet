using Microsoft.AspNetCore.Mvc.RazorPages;

namespace TP2.Pages
{
    public class IndexModel : PageModel
    {
        public List<string> Cities { get; } = new List<string> { "Rio", "São Paulo", "Brasília" };

        public void OnGet()
        {
            
        }
    }
}