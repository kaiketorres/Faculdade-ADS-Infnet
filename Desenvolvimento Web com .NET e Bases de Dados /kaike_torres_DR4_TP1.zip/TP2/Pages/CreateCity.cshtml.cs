using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using TP2.Models;

namespace TP2.Pages
{
    public class CreateCountryModel : PageModel
    {
        public class InputModel
        {
            [Required(ErrorMessage = "O nome do país é obrigatório.")]
            [MinLength(3, ErrorMessage = "O nome do país deve ter no mínimo 3 caracteres.")]
            public string CountryName { get; set; } = "";

            [Required(ErrorMessage = "O código do país é obrigatório.")]
            [StringLength(2, MinimumLength = 2, ErrorMessage = "O código do país deve ter exatamente 2 letras (ex.: BR, US).")]
            public string CountryCode { get; set; } = "";
        }

        [BindProperty]
        public List<InputModel> Countries { get; set; } = Enumerable.Range(0, 5).Select(_ => new InputModel()).ToList();

        public List<Country> CreatedCountries { get; set; } = new List<Country>();

        public void OnGet()
        {
            
            Countries = Enumerable.Range(0, 5).Select(_ => new InputModel()).ToList();
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            
            CreatedCountries = Countries
                .Where(c => !string.IsNullOrEmpty(c.CountryName) && !string.IsNullOrEmpty(c.CountryCode))
                .Select(c => new Country
                {
                    CountryName = c.CountryName,
                    CountryCode = c.CountryCode
                })
                .ToList();

            
            Countries = Enumerable.Range(0, 5).Select(_ => new InputModel()).ToList();

            return Page();
        }
    }
}