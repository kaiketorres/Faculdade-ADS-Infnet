package br.edu.infnet;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CalcularReembolsoTest {

    private CalcularReembolso calculadora;
    private Paciente pacienteDummy;
    private ValidadorValores validadorValores;

    @BeforeEach
    void setUp() {
        calculadora = new CalcularReembolso();
        pacienteDummy = new Paciente();  // objeto fictício
        validadorValores = new ValidadorValores();
    }

    @Test
    void retornaReembolsoCorretoParaValoresValidos() {
        double resultado = calculadora.calcular(200, 70, pacienteDummy);
        validadorValores.compararComMargemDeErro(resultado, 140.0);
    }

    @Test
    void retornaZeroSeValorConsultaForZero() {
        double resultado = calculadora.calcular(0, 70, pacienteDummy);
        validadorValores.compararComMargemDeErro(resultado, 0.0);
    }

    @Test
    void retornaZeroSePercentualCoberturaForZero() {
        double resultado = calculadora.calcular(200, 0, pacienteDummy);
        validadorValores.compararComMargemDeErro(resultado, 0.0);
    }

    @Test
    void retornaValorTotalSePercentualForCemPorcento() {
        double resultado = calculadora.calcular(150, 100, pacienteDummy);
        validadorValores.compararComMargemDeErro(resultado, 150.0);
    }

    @Test
    void lançaExcecaoSeValorConsultaForNegativo() {
        assertThrows(IllegalArgumentException.class, () -> calculadora.calcular(-100, 50, pacienteDummy));
    }

    @Test
    void lançaExcecaoSePercentualCoberturaForNegativo() {
        assertThrows(IllegalArgumentException.class, () -> calculadora.calcular(100, -10, pacienteDummy));
    }

    @Test
    void lançaExcecaoSePercentualCoberturaForMaiorQueCem() {
        assertThrows(IllegalArgumentException.class, () -> calculadora.calcular(100, 150, pacienteDummy));
    }

    @Test
    void limitaReembolsoAoMaximoSeValorConsultaForMaiorQueLimite() {
        double resultado = calculadora.calcular(200, 90, pacienteDummy);
        validadorValores.compararComMargemDeErro(resultado, 150.0);
    }
}
