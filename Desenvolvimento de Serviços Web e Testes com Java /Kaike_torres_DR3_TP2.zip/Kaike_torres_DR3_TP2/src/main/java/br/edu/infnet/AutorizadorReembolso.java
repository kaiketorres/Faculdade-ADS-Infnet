package br.edu.infnet;

public interface AutorizadorReembolso {
    boolean permitirReembolso(double valorSolicitado, double valorLimite);
}
