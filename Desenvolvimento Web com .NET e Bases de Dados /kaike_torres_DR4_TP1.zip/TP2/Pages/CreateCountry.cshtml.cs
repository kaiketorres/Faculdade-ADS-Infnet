using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;

namespace TP2.Pages
{
    public class CreateCityModel : PageModel
    {
        public class InputModel
        {
            [Required(ErrorMessage = "O nome da cidade é obrigatório.")]
            [MinLength(3, ErrorMessage = "O nome da cidade deve ter no mínimo 3 caracteres.")]
            public string CityName { get; set; } = "";
        }

        [BindProperty]
        public InputModel Input { get; set; } = new InputModel();

        public void OnGet()
        {
        }

        public IActionResult OnPost(InputModel input)
        {
            if (!ModelState.IsValid)
            {
                Input = input;
                return Page();
            }

            
            ViewData["SubmittedCityName"] = input.CityName;

            
            Input = new InputModel();

            return Page();
        }
    }
}