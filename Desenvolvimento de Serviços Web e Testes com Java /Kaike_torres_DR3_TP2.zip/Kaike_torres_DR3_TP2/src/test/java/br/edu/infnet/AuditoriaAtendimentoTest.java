package br.edu.infnet;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class AuditoriaAtendimentoTest {

    static class AuditoriaAtendimentoSpy implements AuditoriaAtendimento {
        private boolean consultaRegistrada = false;

        @Override
        public void registrarConsulta(Consulta consulta) {
            consultaRegistrada = true;
        }

        public boolean isConsultaRegistrada() {
            return consultaRegistrada;
        }
    }

    @Test
    void deveRegistrarConsultaAoChamarRegistrarConsulta() {
        AuditoriaAtendimentoSpy auditoriaSpy = new AuditoriaAtendimentoSpy();
        Consulta consultaPadrao = ConsultaHelper.gerarConsultaPadrao();

        auditoriaSpy.registrarConsulta(consultaPadrao);

        assertTrue(auditoriaSpy.isConsultaRegistrada());
    }

    @Test
    void deveRegistrarConsultaQuandoHistoricoRegistraEAuditoriaRegistra() {
        HistoricoConsultasMock historicoMock = new HistoricoConsultasMock();
        AuditoriaAtendimentoSpy auditoriaSpy = new AuditoriaAtendimentoSpy();
        Consulta consultaPadrao = ConsultaHelper.gerarConsultaPadrao();

        historicoMock.registrarConsulta(consultaPadrao);
        auditoriaSpy.registrarConsulta(consultaPadrao);

        assertTrue(auditoriaSpy.isConsultaRegistrada());
    }

    @Test
    void deveRegistrarConsultaMesmoQuandoHistoricoEstaVazio() {
        HistoricoConsultasMock historicoMock = new HistoricoConsultasMock();
        AuditoriaAtendimentoSpy auditoriaSpy = new AuditoriaAtendimentoSpy();
        Consulta consultaPadrao = ConsultaHelper.gerarConsultaPadrao();

        auditoriaSpy.registrarConsulta(consultaPadrao);

        assertTrue(auditoriaSpy.isConsultaRegistrada());
    }
}
