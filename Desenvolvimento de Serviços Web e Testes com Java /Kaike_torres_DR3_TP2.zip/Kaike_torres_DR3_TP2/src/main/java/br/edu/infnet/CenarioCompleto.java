package br.edu.infnet;

public class CenarioCompleto {

    public boolean autorizarConsultaDetalhada(
            PlanoDeSaude planoDeSaude,
            AutorizadorReembolso autorizadorReembolso,
            Consulta consulta) {

        boolean autorizado = autorizadorReembolso.permitirReembolso(
                consulta.getValorConsulta(),
                planoDeSaude.getPercentualCobertura()
        );

        String status = autorizado ? "confirmada" : "negada";
        System.out.println("Consulta " + status + ": " +
                consulta.getNomePaciente() + " - " + consulta.getNomeMedico());

        return autorizado;
    }
}
