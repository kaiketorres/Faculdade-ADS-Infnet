package br.edu.infnet;

public class CalcularReembolso {

    public double calcular(double valorConsulta, double percentualCobertura, Paciente paciente) {
        if (valorConsulta < 0) {
            throw new IllegalArgumentException("O valor da consulta não pode ser negativo.");
        }

        if (percentualCobertura < 0 || percentualCobertura > 100) {
            throw new IllegalArgumentException("O percentual de cobertura deve estar entre 0 e 100.");
        }

        double reembolso = valorConsulta * (percentualCobertura / 100);

        return Math.min(reembolso, 150.0);
    }
}
