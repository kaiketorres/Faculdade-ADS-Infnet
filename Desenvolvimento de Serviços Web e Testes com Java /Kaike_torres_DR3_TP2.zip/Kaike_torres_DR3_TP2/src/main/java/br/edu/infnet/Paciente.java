package br.edu.infnet;

public class Paciente {
}
