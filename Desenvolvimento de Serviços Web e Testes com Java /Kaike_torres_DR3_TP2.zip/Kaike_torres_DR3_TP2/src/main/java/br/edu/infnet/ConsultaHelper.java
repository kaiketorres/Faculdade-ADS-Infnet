package br.edu.infnet;

public class ConsultaHelper {

    public static Consulta gerarConsultaPadrao() {
        return new Consulta(
                "Jao",
                "Silva",
                "Cirurgião",
                125.0,
                "2020-02-09"
        );
    }
}
