using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.IO;
using System.Threading.Tasks;
using System.Linq;

namespace TP2.Pages
{
    public class SaveNoteModel : PageModel
    {
        private readonly IWebHostEnvironment _environment;

        [BindProperty]
        public InputModel Input { get; set; } = new InputModel();

        public string? Message { get; set; }
        public string? FileName { get; set; }
        public string? SelectedFileContent { get; set; }
        public string?[]? FileList { get; set; }
        public string? SelectedFileName { get; set; }

        public class InputModel
        {
            public string? Content { get; set; }
        }

        public SaveNoteModel(IWebHostEnvironment environment)
        {
            _environment = environment;
        }

        public void OnGet()
        {
            // Listar arquivos ao carregar a página
            LoadFileList();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                Message = "Dados inválidos. Por favor, verifique o formulário.";
                return Page();
            }

            if (string.IsNullOrEmpty(Input.Content))
            {
                ModelState.AddModelError(string.Empty, "O conteúdo da nota não pode estar vazio.");
                Message = "O conteúdo da nota não pode estar vazio.";
                LoadFileList();
                return Page();
            }

            try
            {
                
                string timestamp = DateTime.Now.ToString("yyyyMMddHHmmssfff");
                FileName = $"note-{timestamp}.txt";
                string filePath = Path.Combine(_environment.WebRootPath, "files", FileName);

                Directory.CreateDirectory(Path.Combine(_environment.WebRootPath, "files"));

                await System.IO.File.WriteAllTextAsync(filePath, Input.Content);

                Message = "Nota salva com sucesso!";
                LoadFileList();
                return Page();
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, $"Erro ao salvar a nota: {ex.Message}");
                Message = "Ocorreu um erro ao salvar a nota.";
                LoadFileList();
                return Page();
            }
        }

        public IActionResult OnGetView(string fileName)
        {
            if (string.IsNullOrEmpty(fileName))
            {
                return NotFound();
            }

            string filePath = Path.Combine(_environment.WebRootPath, "files", fileName);
            if (!System.IO.File.Exists(filePath))
            {
                return NotFound();
            }

            SelectedFileName = fileName;
            SelectedFileContent = System.IO.File.ReadAllText(filePath);
            LoadFileList();
            return Page();
        }

        private void LoadFileList()
        {
            string filesPath = Path.Combine(_environment.WebRootPath, "files");
            if (Directory.Exists(filesPath))
            {
                FileList = Directory.GetFiles(filesPath, "*.txt")
                    .Select(Path.GetFileName)
                    .ToArray();
            }
            else
            {
                FileList = Array.Empty<string?>();
            }
        }
    }
}