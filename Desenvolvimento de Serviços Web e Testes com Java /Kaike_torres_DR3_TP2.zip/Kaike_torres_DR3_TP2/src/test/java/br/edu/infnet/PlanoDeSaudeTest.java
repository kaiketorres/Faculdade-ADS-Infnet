package br.edu.infnet;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PlanoDeSaudeTest {
    static class PlanoDeSaudeStub implements PlanoDeSaude {
        @Override
        public double getPercentualCobertura() {
            return 50.0;
        }
    }

    @Test
    void retornaPercentualDeCoberturaEsperado() {
        PlanoDeSaude planoDeSaude = new PlanoDeSaudeStub();
        double percentual = planoDeSaude.getPercentualCobertura();
        assertEquals(50.0, percentual);
    }
}
