package br.edu.infnet;

import java.util.List;
import java.util.ArrayList;

public class HistoricoConsultasMock implements HistoricoConsultas {

    private final List<Consulta> consultas = new ArrayList<>();

    @Override
    public void registrarConsulta(Consulta consulta) {
        consultas.add(consulta);
    }

    @Override
    public List<Consulta> obterConsultas() {
        return new ArrayList<>(consultas);
    }
}
