using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;

namespace TP2.Pages
{
    public class CountryFormModel : PageModel
    {
        [BindProperty]
        public InputModel Input { get; set; } = new InputModel();

        public string? Message { get; set; }

        public class InputModel
        {
            [Required(ErrorMessage = "O nome do país é obrigatório.")]
            public string? CountryName { get; set; }

            [Required(ErrorMessage = "O código do país é obrigatório.")]
            public string? CountryCode { get; set; }
        }

        public void OnGet()
        {
            
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                Message = "Dados inválidos. Por favor, verifique o formulário.";
                return Page();
            }

            
            if (!string.IsNullOrEmpty(Input.CountryName) && !string.IsNullOrEmpty(Input.CountryCode))
            {
                char nameFirstChar = char.ToUpper(Input.CountryName[0]);
                char codeFirstChar = char.ToUpper(Input.CountryCode[0]);

                if (nameFirstChar != codeFirstChar)
                {
                    ModelState.AddModelError("Input.CountryCode", "O código do país deve começar com a mesma letra que o nome do país.");
                    Message = "Erro de validação. Veja os detalhes abaixo.";
                    return Page();
                }
            }

        
            Message = $"País registrado: {Input.CountryName} ({Input.CountryCode})";
            return Page();
        }
    }
}