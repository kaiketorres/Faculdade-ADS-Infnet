package br.edu.infnet;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CenarioCompletoTest {

    private AutorizadorReembolso autorizadorReembolso;
    private Consulta consulta;

    static class PlanoDeSaudeStub implements PlanoDeSaude {
        @Override
        public double getPercentualCobertura() {
            return 50.0;
        }
    }

    @BeforeEach
    void setUp() {
        autorizadorReembolso = mock(AutorizadorReembolso.class);
        consulta = ConsultaHelper.gerarConsultaPadrao();
    }

    @Test
    void autorizaConsultaQuandoReembolsoEhPermitido() {
        PlanoDeSaude planoDeSaude = new PlanoDeSaudeStub();
        CenarioCompleto cenario = new CenarioCompleto();

        when(autorizadorReembolso.permitirReembolso(
                consulta.getValorConsulta(),
                planoDeSaude.getPercentualCobertura()
        )).thenReturn(true);

        boolean resultado = cenario.autorizarConsultaDetalhada(
                planoDeSaude,
                autorizadorReembolso,
                consulta
        );

        verify(autorizadorReembolso).permitirReembolso(
                consulta.getValorConsulta(),
                planoDeSaude.getPercentualCobertura()
        );

        assertTrue(resultado);
    }
}
