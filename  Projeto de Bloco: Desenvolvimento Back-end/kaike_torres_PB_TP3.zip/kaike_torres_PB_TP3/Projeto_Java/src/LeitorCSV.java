import java.io.*;
import java.util.*;

public class LeitorCSV {
    public static void main(String[] args) {
        String caminho = "usuarios.csv"; // Altere conforme necessário

        try (BufferedReader br = new BufferedReader(new FileReader(caminho))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                String[] dados = linha.split(",");
                System.out.println(Arrays.toString(dados));
            }
        } catch (IOException e) {
            System.out.println("Erro ao ler o arquivo: " + e.getMessage());
        }
    }
}
