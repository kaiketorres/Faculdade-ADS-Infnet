package br.edu.infnet;

import static org.mockito.Mockito.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AutorizarReembolsoTest {

    private AutorizadorReembolso autorizadorReembolsoMock;

    @BeforeEach
    void setup() {
        autorizadorReembolsoMock = mock(AutorizadorReembolso.class);
    }

    @Test
    void deveLancarExcecaoQuandoValorSolicitadoExcedeLimite() {
        double valorConsulta = 200;
        double percentualCobertura = 150;

        when(autorizadorReembolsoMock.permitirReembolso(valorConsulta, percentualCobertura))
                .thenThrow(new IllegalArgumentException("O valor solicitado para reembolso é maior que o limite do paciente"));

        assertThrows(IllegalArgumentException.class, () -> {
            autorizadorReembolsoMock.permitirReembolso(valorConsulta, percentualCobertura);
        });
    }
}
