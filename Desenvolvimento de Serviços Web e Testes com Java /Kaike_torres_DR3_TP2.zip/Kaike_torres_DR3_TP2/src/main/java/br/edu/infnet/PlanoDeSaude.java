package br.edu.infnet;

public interface PlanoDeSaude {
    double getPercentualCobertura();
}
