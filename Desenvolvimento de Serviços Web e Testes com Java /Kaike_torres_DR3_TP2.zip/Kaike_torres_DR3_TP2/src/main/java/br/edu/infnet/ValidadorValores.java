package br.edu.infnet;

public class ValidadorValores {

    private static final double MARGEM_ERRO_PADRAO = 0.01;

    public boolean compararComMargemDeErro(double valor1, double valor2) {
        return compararComMargemDeErro(valor1, valor2, MARGEM_ERRO_PADRAO);
    }

    public boolean compararComMargemDeErro(double valor1, double valor2, double margemErro) {
        double diferenca = Math.abs(valor1 - valor2);
        return diferenca <= margemErro;
    }
}
