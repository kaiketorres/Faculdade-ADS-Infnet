package br.edu.infnet;

import java.util.List;

public interface HistoricoConsultas {

    void registrarConsulta(Consulta consulta);

    List<Consulta> obterConsultas();
}
