using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace TP2.Pages
{
    public class DownloadFileModel : PageModel
    {
        private readonly IWebHostEnvironment _environment;

        public DownloadFileModel(IWebHostEnvironment environment)
        {
            _environment = environment;
        }

        public IActionResult OnGet(string filename)
        {
            if (string.IsNullOrEmpty(filename))
            {
                return NotFound();
            }

            string filePath = Path.Combine(_environment.WebRootPath, "files", filename);
            if (!System.IO.File.Exists(filePath))
            {
                return NotFound();
            }

            var fileBytes = System.IO.File.ReadAllBytes(filePath);
            return File(fileBytes, "text/plain", filename); // Correto: byte[], contentType, fileDownloadName
        }
    }
}