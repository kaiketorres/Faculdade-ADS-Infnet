import java.io.*;

public class EscritorCSV {
    public static void main(String[] args) {
        String caminho = "saida.csv";

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(caminho))) {
            bw.write("id,nome,email,senha,tipo\n");
            bw.write("1,Ana Admin,ana@admin.com,senha123,Administrador\n");
            bw.write("2,Beto Recrutador,beto@empresa.com,senha456,Recrutador\n");
            bw.write("3,Clara Profissional,clara@prof.com,senha789,Profissional\n");
            System.out.println("Arquivo CSV criado com sucesso!");
        } catch (IOException e) {
            System.out.println("Erro ao escrever o arquivo: " + e.getMessage());
        }
    }
}
