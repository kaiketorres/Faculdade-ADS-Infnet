package br.edu.infnet;

public interface AuditoriaAtendimento {
    void registrarConsulta(Consulta consulta);
}
